/**
 * Password and form validation utilities
 * 
 * This module provides comprehensive validation functions and regex patterns
 * for user registration forms with password complexity requirements.
 */

import { PASSWORD_RULES, ERROR_MESSAGES } from '../constants';

/**
 * Complete password validation regex
 * This regex ensures at least one uppercase, one lowercase, one digit, 
 * one special character, and minimum 8 characters.
 * 
 * Technical breakdown of the regex pattern:
 * - ^                      : Start of string anchor (prevents partial matches)
 * - (?=.*[a-z])           : Positive lookahead for lowercase letter
 * - (?=.*[A-Z])           : Positive lookahead for uppercase letter  
 * - (?=.*\d)              : Positive lookahead for digit (\d = [0-9])
 * - (?=.*[!@#$%^&*()_+\-=[\]{};':"|,.<>/?])  : Positive lookahead for special character
 * - .{8,}                 : Match any character (except newline) 8 or more times
 * - $                     : End of string anchor
 * 
 * Why use lookaheads instead of capturing groups?
 * Lookaheads don't consume characters, so they check requirements without
 * affecting the main pattern match. This approach is more elegant than
 * trying to match all character types in a specific order.
 * 
 * Note: The hyphen in [\]{};':\"|,.<>/?] is escaped as \- to avoid
 * being interpreted as a character range operator.
 */
export const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]).{8,}$/;

/**
 * Individual validation regex patterns for detailed error messages
 */
export const ValidationPatterns = {
  // Matches at least one lowercase letter (a-z)
  LOWERCASE: /(?=.*[a-z])/,
  
  // Matches at least one uppercase letter (A-Z)
  UPPERCASE: /(?=.*[A-Z])/,
  
  // Matches at least one digit (0-9)
  DIGIT: /(?=.*\d)/,
  
  // Matches at least one special character from the allowed set
  SPECIAL_CHAR: /(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/,
} as const;

/**
 * Validates password using the complete regex pattern
 * @param password - The password string to validate
 * @returns true if password meets all requirements, false otherwise
 */
export const isPasswordValid = (password: string): boolean => {
  return passwordRegex.test(password);
};

/**
 * Validates password with detailed error reporting
 * Returns the first validation error encountered, or undefined if valid
 * @param password - The password string to validate
 * @returns Error message string or undefined if valid
 */
export const validatePasswordDetailed = (password: string): string | undefined => {
  if (password.length < PASSWORD_RULES.MIN_LENGTH) {
    return ERROR_MESSAGES.PASSWORD_MIN_LENGTH;
  }
  if (!ValidationPatterns.LOWERCASE.test(password)) {
    return ERROR_MESSAGES.PASSWORD_LOWERCASE;
  }
  if (!ValidationPatterns.UPPERCASE.test(password)) {
    return ERROR_MESSAGES.PASSWORD_UPPERCASE;
  }
  if (!ValidationPatterns.DIGIT.test(password)) {
    return ERROR_MESSAGES.PASSWORD_DIGIT;
  }
  if (!ValidationPatterns.SPECIAL_CHAR.test(password)) {
    return ERROR_MESSAGES.PASSWORD_SPECIAL;
  }
  return undefined;
};

/**
 * Validates username according to business rules
 * @param username - The username string to validate
 * @returns Error message string or undefined if valid
 */
export const validateUsername = (username: string): string | undefined => {
  if (!username.trim()) {
    return ERROR_MESSAGES.USERNAME_REQUIRED;
  }
  if (username.length < PASSWORD_RULES.MIN_USERNAME_LENGTH) {
    return ERROR_MESSAGES.USERNAME_MIN_LENGTH;
  }
  return undefined;
};

/**
 * Validates entire form data
 * @param formData - Object containing username and password
 * @returns Object with validation errors, empty if all valid
 */
export const validateForm = (formData: { username: string; password: string }) => {
  const errors: { username?: string; password?: string } = {};
  
  const usernameError = validateUsername(formData.username);
  if (usernameError) {
    errors.username = usernameError;
  }
  
  const passwordError = validatePasswordDetailed(formData.password);
  if (passwordError) {
    errors.password = passwordError;
  }
  
  return errors;
};

/**
 * Gets password strength information
 * @param password - The password to analyze
 * @returns Object with strength details
 */
export const getPasswordStrength = (password: string) => {
  const checks = {
    length: password.length >= PASSWORD_RULES.MIN_LENGTH,
    lowercase: ValidationPatterns.LOWERCASE.test(password),
    uppercase: ValidationPatterns.UPPERCASE.test(password),
    digit: ValidationPatterns.DIGIT.test(password),
    special: ValidationPatterns.SPECIAL_CHAR.test(password),
  };
  
  const passedChecks = Object.values(checks).filter(Boolean).length;
  const strength = passedChecks === 5 ? 'Strong' : 
                  passedChecks >= 3 ? 'Medium' : 'Weak';
  
  return {
    checks,
    passedChecks,
    totalChecks: 5,
    strength,
    isValid: passedChecks === 5,
  };
};
