/**
 * Password validation constants and rules
 * 
 * Centralized configuration for validation logic to ensure consistency
 * and make updates easier. These constants are used by both the validation
 * utilities and form components.
 * 
 * Design decision: Using 'as const' assertions to create readonly tuples
 * and get better TypeScript inference.
 */

export const PASSWORD_RULES = {
  MIN_LENGTH: 8,
  MIN_USERNAME_LENGTH: 3,
} as const;

export const PASSWORD_REGEX = {
  // Matches at least one lowercase letter (a-z)
  LOWERCASE: /(?=.*[a-z])/,
  
  // Matches at least one uppercase letter (A-Z)
  UPPERCASE: /(?=.*[A-Z])/,
  
  // Matches at least one digit (0-9)
  DIGIT: /(?=.*\d)/,
  
  // Matches at least one special character from the allowed set
  SPECIAL_CHAR: /(?=.*[!@#$%^&*()_+\-=[\]{};':"|,.<>/?])/,
} as const;

export const ERROR_MESSAGES = {
  USERNAME_REQUIRED: 'Username is required',
  USERNAME_MIN_LENGTH: `Username must be at least ${PASSWORD_RULES.MIN_USERNAME_LENGTH} characters long`,
  PASSWORD_MIN_LENGTH: `Password must be at least ${PASSWORD_RULES.MIN_LENGTH} characters long`,
  PASSWORD_LOWERCASE: 'Password must contain at least one lowercase letter',
  PASSWORD_UPPERCASE: 'Password must contain at least one uppercase letter',
  PASSWORD_DIGIT: 'Password must contain at least one number',
  PASSWORD_SPECIAL: 'Password must contain at least one special character',
} as const;

export const TEST_IDS = {
  USERNAME_INPUT: 'username-input',
  PASSWORD_INPUT: 'password-input',
  USERNAME_ERROR: 'username-error',
  PASSWORD_ERROR: 'password-error',
  SUBMIT_BUTTON: 'submit-button',
  FORM: 'create-user-form',
} as const;
