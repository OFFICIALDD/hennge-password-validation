<script setup lang="ts">
/**
 * Vue 3 Password Validation Form Component
 * 
 * Using Composition API with <script setup> syntax for cleaner, more readable code.
 * This approach is preferred in Vue 3 as it reduces boilerplate and provides
 * better TypeScript integration compared to Options API.
 */
import { ref } from 'vue';
import { TEST_IDS } from './constants';
import { validateForm } from './utils/validation';

// Define events this component can emit to parent
// Using TypeScript interface for better type safety
const emit = defineEmits<{
  'create-successful': [];
}>();

// Reactive state using Vue 3's ref() - equivalent to useState in React
// Chose ref() over reactive() because we're working with primitive values
const username = ref('');
const password = ref('');

// Error state - separated from input values for better UX
// Only shows errors after validation attempt, not while user is typing
const errors = ref<{ username?: string; password?: string }>({});

/**
 * Form submission handler with validation
 * 
 * Design decision: Using the same validation approach as React component
 * to maintain consistency between implementations. The shared validation
 * utility ensures identical behavior across both frameworks.
 */
const handleSubmit = (e: Event) => {
  e.preventDefault();
  
  // Extract values from Vue refs for validation
  // Note: .value is required to access ref contents in Vue 3
  const validationErrors = validateForm({ 
    username: username.value, 
    password: password.value 
  });
  errors.value = validationErrors;

  // Emit success event to parent component if validation passes
  if (Object.keys(validationErrors).length === 0) {
    emit('create-successful');
  }
};
</script>

<template>
  <div class="form-wrapper">
    <form class="form" @submit="handleSubmit" :data-testid="TEST_IDS.FORM">
      <label for="username">Username</label>
      <input
        id="username"
        v-model="username"
        type="text"
        :class="{ error: errors.username }"
        :data-testid="TEST_IDS.USERNAME_INPUT"
        :aria-describedby="errors.username ? TEST_IDS.USERNAME_ERROR : undefined"
        :aria-invalid="errors.username ? 'true' : 'false'"
        tabindex="1"
      />
      <span
        v-if="errors.username"
        :id="TEST_IDS.USERNAME_ERROR"
        :data-testid="TEST_IDS.USERNAME_ERROR"
        class="error-text"
        role="alert"
      >
        {{ errors.username }}
      </span>

      <label for="password">Password</label>
      <input
        id="password"
        v-model="password"
        type="password"
        :class="{ error: errors.password }"
        :data-testid="TEST_IDS.PASSWORD_INPUT"
        :aria-describedby="errors.password ? TEST_IDS.PASSWORD_ERROR : undefined"
        :aria-invalid="errors.password ? 'true' : 'false'"
        tabindex="2"
      />
      <span
        v-if="errors.password"
        :id="TEST_IDS.PASSWORD_ERROR"
        :data-testid="TEST_IDS.PASSWORD_ERROR"
        class="error-text"
        role="alert"
      >
        {{ errors.password }}
      </span>

      <button
        type="submit"
        class="submit-button"
        :data-testid="TEST_IDS.SUBMIT_BUTTON"
        tabindex="3"
      >
        Create User
      </button>
    </form>
  </div>
</template>

<style scoped>
.form-wrapper {
  max-width: 500px;
  width: 80%;
  background-color: #efeef5;
  padding: 24px;
  margin: auto;
  border-radius: 8px;
}

.form {
  display: flex;
  gap: 8px;
  flex-direction: column;
}

label {
  font-weight: 700;
}

input {
  outline: none;
  padding: 8px 16px;
  height: 40px;
  font-size: 14px;
  background-color: #f8f7fa;
  border: 1px solid rgba(0, 0, 0, 0.12);
  border-radius: 4px;
}

.submit-button {
  outline: none;
  border-radius: 4px;
  border: 1px solid rgba(0, 0, 0, 0.12);
  background-color: #7135d2;
  color: white;
  font-size: 16px;
  font-weight: 500;
  height: 40px;
  padding: 0 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 8px;
  align-self: flex-end;
  cursor: pointer;
}

input.error {
  border-color: #e53e3e;
  background-color: #fed7d7;
}

.error-text {
  color: #e53e3e;
  font-size: 12px;
  margin-top: 4px;
}
</style>
