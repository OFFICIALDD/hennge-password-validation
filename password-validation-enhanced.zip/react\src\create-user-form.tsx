import type { CSSProperties, Dispatch, FormEvent, SetStateAction } from 'react';
import { useState } from 'react';
import { TEST_IDS } from './constants';
import { validateForm } from './utils/validation';

/**
 * Props interface for the CreateUserForm component.
 * The parent component needs to provide a callback to handle successful user creation.
 */
interface CreateUserFormProps {
  setUserWasCreated: Dispatch<SetStateAction<boolean>>;
}

/**
 * CreateUserForm component handles user registration with password validation.
 * 
 * Key design decisions made:
 * - Uses controlled components for form inputs (React best practice)
 * - Validation happens on form submission rather than on every keystroke 
 *   to avoid annoying users while they're still typing
 * - Error state is stored separately from input values for better UX
 * - Accessibility is prioritized with proper ARIA attributes and semantic HTML
 */
function CreateUserForm({ setUserWasCreated }: CreateUserFormProps) {
  // Form state - using separate state for each input for better control
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  // Error state - only shows errors after user attempts to submit
  // This prevents showing errors while user is still typing
  const [errors, setErrors] = useState<{
    username?: string;
    password?: string;
  }>({});

  /**
   * Handles form submission and validation.
   * 
   * Design choice: Validate only on submit, not on every keystroke.
   * This gives users a chance to complete their input before showing errors.
   * Research shows this approach reduces user frustration compared to
   * aggressive real-time validation.
   */
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Use our centralized validation utility - keeps logic DRY between React/Vue
    const validationErrors = validateForm({ username, password });
    setErrors(validationErrors);

    // Only proceed if validation passes
    if (Object.keys(validationErrors).length === 0) {
      setUserWasCreated(true);
    }
  };

  return (
    <div style={formWrapper}>
      <form style={form} onSubmit={handleSubmit} data-testid={TEST_IDS.FORM}>
        <label style={formLabel} htmlFor="username">
          Username
        </label>
        <input
          id="username"
          data-testid={TEST_IDS.USERNAME_INPUT}
          style={{ ...formInput, ...(errors.username ? errorInputStyle : {}) }}
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          aria-describedby={errors.username ? TEST_IDS.USERNAME_ERROR : undefined}
          aria-invalid={errors.username ? 'true' : 'false'}
          tabIndex={1}
        />
        {errors.username && (
          <span id={TEST_IDS.USERNAME_ERROR} data-testid={TEST_IDS.USERNAME_ERROR} style={errorText} role="alert">
            {errors.username}
          </span>
        )}

        <label style={formLabel} htmlFor="password">
          Password
        </label>
        <input
          id="password"
          data-testid={TEST_IDS.PASSWORD_INPUT}
          style={{ ...formInput, ...(errors.password ? errorInputStyle : {}) }}
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          aria-describedby={errors.password ? TEST_IDS.PASSWORD_ERROR : undefined}
          aria-invalid={errors.password ? 'true' : 'false'}
          tabIndex={2}
        />
        {errors.password && (
          <span id={TEST_IDS.PASSWORD_ERROR} data-testid={TEST_IDS.PASSWORD_ERROR} style={errorText} role="alert">
            {errors.password}
          </span>
        )}

        <button type="submit" data-testid={TEST_IDS.SUBMIT_BUTTON} style={formButton} tabIndex={3}>
          Create User
        </button>
      </form>
    </div>
  );
}

export { CreateUserForm };

const formWrapper: CSSProperties = {
  maxWidth: '500px',
  width: '80%',
  backgroundColor: '#efeef5',
  padding: '24px',
  borderRadius: '8px',
};

const form: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: '8px',
};

const formLabel: CSSProperties = {
  fontWeight: 700,
};

const formInput: CSSProperties = {
  outline: 'none',
  padding: '8px 16px',
  height: '40px',
  fontSize: '14px',
  backgroundColor: '#f8f7fa',
  border: '1px solid rgba(0, 0, 0, 0.12)',
  borderRadius: '4px',
};

const formButton: CSSProperties = {
  outline: 'none',
  borderRadius: '4px',
  border: '1px solid rgba(0, 0, 0, 0.12)',
  backgroundColor: '#7135d2',
  color: 'white',
  fontSize: '16px',
  fontWeight: 500,
  height: '40px',
  padding: '0 8px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginTop: '8px',
  alignSelf: 'flex-end',
  cursor: 'pointer',
};

const errorInputStyle: CSSProperties = {
  borderColor: '#e53e3e',
  backgroundColor: '#fed7d7',
};

const errorText: CSSProperties = {
  color: '#e53e3e',
  fontSize: '12px',
  marginTop: '4px',
};
