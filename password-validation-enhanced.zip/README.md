# Password Validation Challenge

This project demonstrates password validation form implementations in both **React** and **Vue** with TypeScript.

## Quick Start

Choose either implementation to run:

### Option 1: React Application
```bash
cd react
npm install
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### Option 2: Vue Application  
```bash
cd vue
npm install
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

## What's Included

- **React Implementation**: Modern React with hooks, TypeScript, and Vite
- **Vue Implementation**: Vue 3 Composition API with TypeScript and Vite
- **Shared Features**: Identical validation logic, accessibility features, and professional UI

## Password Requirements

Both implementations enforce the same validation rules:
- Minimum 8 characters
- At least one uppercase letter (A-Z)
- At least one lowercase letter (a-z) 
- At least one number (0-9)
- At least one special character (!@#$%^&*()_+-=[]{}|;':"\\|,.<>?/)

## Development Commands

Each project supports:
```bash
npm run dev        # Start development server
npm run build      # Build for production
npm run preview    # Preview production build
npm run validate   # TypeScript type checking
npm run lint       # Code linting
npm run format     # Code formatting
```

## Project Structure

```
password-validation-enhanced/
├── README.md              # This file
├── react/                 # React + TypeScript implementation
│   ├── src/
│   │   ├── utils/validation.ts
│   │   ├── constants.ts
│   │   └── components...
│   └── package.json
└── vue/                   # Vue + TypeScript implementation
    ├── src/
    │   ├── utils/validation.ts
    │   ├── constants.ts
    │   └── components...
    └── package.json
```

## Testing the Applications

Try these test cases:

**Valid credentials:**
- Username: `testuser`
- Password: `Test123!`

**Invalid examples:**
- Password too short: `Test1!`
- Missing uppercase: `test123!`
- Missing special char: `Test1234`

Both implementations provide real-time validation feedback with clear error messages.
